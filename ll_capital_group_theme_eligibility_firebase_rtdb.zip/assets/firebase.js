
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-analytics.js";
import { getDatabase, ref, push, set } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCytLCYcEVx6GnxUA_24UWJxPREEfScMH0",
  authDomain: "llcapitalintake.firebaseapp.com",
  projectId: "llcapitalintake",
  // IMPORTANT: Confirm this exact URL in Firebase Console → Realtime Database
  databaseURL: "https://llcapitalintake-default-rtdb.firebaseio.com",
  storageBucket: "llcapitalintake.firebasestorage.app",
  messagingSenderId: "616237520583",
  appId: "1:616237520583:web:bf75062f3ffdc759f650e2",
  measurementId: "G-4G8RYRCLW7"
};

const app = initializeApp(firebaseConfig);
try { getAnalytics(app); } catch (e) { /* analytics may fail in some local/file contexts */ }

const db = getDatabase(app);

// Expose minimal helpers for non-module scripts
window.LLFirebase = { db, ref, push, set };

console.log("Firebase initialized (Analytics + RTDB)");
