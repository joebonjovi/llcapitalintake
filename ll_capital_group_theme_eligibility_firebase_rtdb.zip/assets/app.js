
(function(){
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);

  // Mobile menu
  const sheet = $("#sheet");
  const burger = $("#hamburger");
  if (burger && sheet){
    burger.addEventListener("click", () => sheet.style.display = "block");
    sheet.addEventListener("click", (e) => { if (e.target === sheet) sheet.style.display = "none"; });
    $$(".sheetLink").forEach(a => a.addEventListener("click", () => sheet.style.display = "none"));
  }

  // Toast (if present)
  const toast = (title, msg) => {
    const t = $("#toast");
    if (!t) return;
    const tt = $("#toastTitle");
    const tm = $("#toastMsg");
    if (tt) tt.textContent = title;
    if (tm) tm.textContent = msg;
    t.style.display = "block";
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(() => (t.style.display = "none"), 5200);
  };

  const normalizeMoney = (val) => {
    const n = String(val || "").replace(/[^\d]/g,"");
    if(!n) return "";
    return Number(n).toLocaleString();
  };

  // BASIC ELIGIBILITY FORM → Firebase RTDB
  const form = $("#quickForm");
  if (form){
    ["#qAmt","#qRevenue"].forEach(id => {
      const el = $(id);
      if(!el) return;
      el.addEventListener("input", () => el.value = normalizeMoney(el.value));
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!form.checkValidity()){ form.reportValidity(); return; }

      const payload = {
        name: $("#qName")?.value?.trim() || "",
        business_name: $("#qBiz")?.value?.trim() || "",
        requested_amount: $("#qAmt")?.value?.trim() || "",
        purpose: $("#qPurpose")?.value || "",
        monthly_revenue: $("#qRevenue")?.value?.trim() || "",
        phone: $("#qPhone")?.value?.trim() || "",
        submitted_at: new Date().toISOString(),
        user_agent: navigator.userAgent,
        page: location.href
      };

      try{
        if (!window.LLFirebase) throw new Error("Firebase not loaded");
        const { db, ref, push, set } = window.LLFirebase;
        const node = push(ref(db, "eligibility_submissions"));
        await set(node, payload);

        toast("Submitted ✅","Saved to your database.");
        form.reset();
      }catch(err){
        console.error(err);
        toast("Not saved","Firebase write failed. Check RTDB rules + databaseURL.");
      }
    });
  }
})();
